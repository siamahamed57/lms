<?php
// The login form and logic have been consolidated into pages/account.php
// Redirecting to the unified account page.
header('Location: ../../index.php?_page=account#login-tab');
exit;
?>
